const String GEMINI_API_KEY = "AIzaSyBBhKSdVy_R4VRTj5zLkN27uxottFTm5-Q";

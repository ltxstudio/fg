package com.example.gemini_chat_app_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
